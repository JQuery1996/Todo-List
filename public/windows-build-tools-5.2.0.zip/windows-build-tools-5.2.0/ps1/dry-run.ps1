# Dry-run, do nothing
Write-Output "Passed arguments: $args"
